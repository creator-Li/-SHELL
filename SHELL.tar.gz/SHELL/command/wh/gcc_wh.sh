gcc cat.c -o cat -lm
gcc date.c -o date
gcc mkdir.c -o mkdir
gcc touch.c -o touch
