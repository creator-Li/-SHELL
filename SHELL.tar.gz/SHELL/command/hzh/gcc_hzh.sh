gcc hzh.c -o hzh
