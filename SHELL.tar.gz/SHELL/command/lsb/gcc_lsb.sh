gcc cp.c -o cp
gcc mv.c -o mv
gcc rm.c -o rm
